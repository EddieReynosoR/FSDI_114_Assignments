# FSDI_114_Jupyter
### Jupyter Notes
This repository has jupyter notes with algorithms from Python
